declare module 'react-navigation' {
  declare module.exports: any;
}
declare module 'react-native' {
  declare module.exports: any;
}
declare module 'react-native-paper' {
  declare module.exports: any;
}
declare module 'react-native-paper/types' {
  declare module.exports: any;
}
declare module 'moment' {
  declare module.exports: any;
}
declare module 'react-native-render-html' {
  declare module.exports: any;
}
